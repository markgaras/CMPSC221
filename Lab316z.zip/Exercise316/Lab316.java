/**
 * CMPSCI 221 Exercise 3.16
 * Lab316.java  
 * Purpose: Target-Heart-Rate Calculator  
 *  
 * @author Mark Garas  
 * @version 1.0 1/30/2021
 */ 
package lab316;
import java.util.Scanner;

/**
 * @author markb
 */
public class Lab316 {
    // This will interact with the user to get the necessary information needed
    // to continue the program, calculate, return, and display the user's
    // information
    public static void main(String[] args) {
        System.out.println("This program will take your first name, ");
        System.out.println("last name, and birth year, month, and day to ");
        System.out.println("calculate your optimal heart rate range in beats ");
        System.out.println("per minute, as well as your maximum heart rate.");
        System.out.println("_________________________________________________");
        
        Scanner reader = new Scanner(System.in);
        System.out.print("Please enter your first name: ");
        String firstName = reader.nextLine();
        System.out.print("Please enter your last name: ");
        String lastName = reader.nextLine();
        System.out.print("Please enter your birth year: ");
        int birthYear = reader.nextInt();
        System.out.print("Please enter your birth month (1-12): ");
        int birthMonth = reader.nextInt();
        System.out.print("Please enter your birth day (1-31): ");
        int birthDay = reader.nextInt();
        System.out.print("Please enter the present year: ");
        int presentYear = reader.nextInt();
        System.out.print("Please enter your present month (1-12): ");
        int presentMonth = reader.nextInt();
        System.out.print("Please enter your present day (1-31): ");
        int presentDay = reader.nextInt();
        
        // Making the Heart Rate object and final calculations
        HeartRates userHeartRate = new HeartRates(firstName, lastName,
                birthYear, birthMonth, birthDay, presentYear, presentMonth,
                presentDay);
        doFinalCalculations(userHeartRate);
    }
    
    // This will calculate the numebers to then display
    // @param userHeartRate is the user's heart rate object
    public static void doFinalCalculations(HeartRates userHeartRate){
        double userAge = userHeartRate.calcAge();
        int userMax = userHeartRate.maxHeartRate(userAge);
        double userLowerTarget = userHeartRate.targetMinHeartRate(userMax);
        double userHigherTarget = userHeartRate.targetMaxHeartRate(userMax);
        System.out.println("_________________________________________________");
        System.out.println("Your Name: " + userHeartRate.getFirst() + " " + 
            userHeartRate.getLast());
        System.out.println("Your Birthday: " + userHeartRate.getMonth() + "/" 
            + userHeartRate.getDay() + "/" + userHeartRate.getYear());
        System.out.println("Today's Date: " + userHeartRate.getPresentMonth() + 
            "/" + userHeartRate.getPresentDay() + "/" + 
                userHeartRate.getPresentYear());
        System.out.println("Your Healthy Heart Rate in Beats per minute: " + 
                (int)userLowerTarget + "-" + (int)userHigherTarget + " bpm");
        System.out.println("Your MAX Heart Rate: " + userMax + " bpm");
    }
}