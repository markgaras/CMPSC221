/*
 * CMPSCI 221 Exercise 8.6 SavingsAccount Main Tester Program
 * Lab860.java  
 * Purpose: To host the SavingsAccount object that simulates user bank accounts
 *  
 * @author Mark Garas  
 * @version 1.0 2/18/2021
 */ 
package lab860;

public class Lab860 {

    public static void main(String[] args) {
        System.out.println("This main class will test the savingsAccount "
                + "object class.");
        
        savingsAccount.modifyInterestRate(.04);
        
        savingsAccount saver1 = new savingsAccount();
        saver1.savingsAccount(2000);
        System.out.println("Initial account #1 bal: " + saver1.getBalance());
        for (int i = 0; i < saver1.getMonths(); i++) {
            saver1.calculateMonthlyInterest();
            System.out.println("After " + (i+1) + " month(s), balance is: " + 
                    saver1.getBalance());
        }
        
        System.out.println("_________________________________________________");
        
        savingsAccount saver2 = new savingsAccount();
        saver2.savingsAccount(3000);
        System.out.println("Initial account #3 bal: " + saver2.getBalance());
        for (int j = 0; j < saver2.getMonths(); j++) {
            saver2.calculateMonthlyInterest();
            System.out.println("After " + (j+1) + " month(s), balance is: " + 
                    saver2.getBalance());
        }
        
        System.out.println("_________________________________________________");

        savingsAccount.modifyInterestRate(.05);
        
        saver1.savingsAccount(2000);
        System.out.println("Initial account #1 bal: " + saver1.getBalance());
        for (int i = 0; i < saver1.getMonths(); i++) {
            saver1.calculateMonthlyInterest();
            System.out.println("After " + (i+1) + " month(s), balance is: " + 
                    saver1.getBalance());
        }
        
        System.out.println("_________________________________________________");
        
        saver2.savingsAccount(3000);
        System.out.println("Initial account #3 bal: " + saver2.getBalance());
        for (int j = 0; j < saver2.getMonths(); j++) {
            saver2.calculateMonthlyInterest();
            System.out.println("After " + (j+1) + " month(s), balance is: " + 
                    saver2.getBalance());
        }
    }
}

// Each of the four sections updates the balance, prints the balance, and 
// calculates and displays the monthly interest 12 times (for a total year), 
// and then prints the balance after each of the months