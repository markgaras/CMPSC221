/*
 * CMPSCI 221 Exercise 8.6 SavingsAccount Class
 * savingsAccount.java  
 * Purpose: SavingsAccount object that simulates user bank accounts
 *  
 * @author Mark Garas  
 * @version 1.0 2/18/2021
 */ 
package lab860;

public class savingsAccount {
    public static double annualInterestRate = 0;
    private double savingsBalance = 0;
    public static double monthsInYear = 12;
    
    void savingsAccount(int blnc) {
        savingsBalance = blnc;
    }
    
    void calculateMonthlyInterest() {
        savingsBalance += savingsBalance * annualInterestRate / monthsInYear;
    }
    
    static void modifyInterestRate(double intrst){
        annualInterestRate = intrst;
    }
    
    double getBalance(){
        return savingsBalance;
    }
    
    double getMonths() {
        return monthsInYear;
    }
}