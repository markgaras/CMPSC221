/**
 * CMPSCI 221 Exercise 4.17 (MPG Object)
 * MPGHistory.java  
 * Purpose: To host the MPG tracking object for Lab417.java
 *  
 * @author Mark Garas  
 * @version 1.0 2/3/2021
 */ 
package lab417;

public class MPGHistory {
    private static int[] miles, gallons;
    private static double[] mpg;
    private static double totalMiles, totalGallons, totalMPG; 
    
    // @param mls is the array of miles for each trip the user took, @param 
    // gllns is the array of gallons for each trip the user took
    public MPGHistory(int[] mls, int[] gllns) {
        miles = mls.clone();
        gallons = gllns.clone();
        mpg = new double[miles.length];
    }
    
    // This method is used to print out each mpg
    public static void calcTripMPG() {
        for (int i = 0; i < miles.length; i++){
            mpg[i] = (double)miles[i] / (double)gallons[i];
            System.out.println("Your Trip #" + i + " MPG was " + mpg[i] 
                    + " mpg");
        } 
    }
    
    // This method is used to print out the total mpg
    public static void calcTotalMPG() {
        for (int i = 0; i < miles.length; i++){
            totalMiles += miles[i];
            totalGallons += gallons[i];
        }
        totalMPG = totalMiles / totalGallons;
        System.out.println("Your total MPG for all trips was " + totalMPG 
                + " mpg");
    }
}