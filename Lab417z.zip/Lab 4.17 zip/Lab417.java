/**
 * CMPSCI 221 Exercise 4.17
 * Lab417.java  
 * Purpose: Gas Mileage Calculator
 *  
 * @author Mark Garas  
 * @version 1.0 2/3/2021
 */ 
package lab417;

import java.util.Scanner;

public class Lab417 {
    public static int[] mileInputs, gallonInputs;
    public static int trips;
    
    // This class is the main program that interacts with the user in order to
    // get inputs and calculate the mpg information with the MPGHistory class
    public static void main(String[] args) {
        System.out.println("This calculator will ask you for mile and gallon "
                + "inputs and return your MPG for each trip and in total.");
        System.out.print("Please enter the number of trips: ");
        Scanner console = new Scanner(System.in);
        trips = console.nextInt();
        
        // Setting the size of the miles and gallons arrays
        mileInputs = new int[trips];
        gallonInputs = new int[trips];
        
        System.out.println("_________________________________________________");
        
        // Getting the different miles for each trip
        for (int i = 0; i < trips; i++){
            System.out.print("Please enter the miles driven for Trip #" + 
                    (i+1) + ": ");
            mileInputs[i] = console.nextInt();  
        }
        
        System.out.println("_________________________________________________");
        
        // Getting the different gallons for each trip
        for (int j = 0; j < trips; j++){
            System.out.print("Please enter the gallons used for Trip #" + 
                    (j+1) + ": ");
            gallonInputs[j] = console.nextInt();
        }
        
        System.out.println("_________________________________________________");
        
        // Creating MPGHistory object to keep track of the user's driving 
        // history
        MPGHistory ledger = new MPGHistory(mileInputs, gallonInputs);
        ledger.calcTripMPG();
        ledger.calcTotalMPG();
    }
}