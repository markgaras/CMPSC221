/*
 * CMPSCI 221 Exercise 8.14
 * Lab814.java  
 * Purpose: To take different parameters and initialize a Date object to output
 *          the date in different ways
 *  
 * @author Mark Garas  
 * @version 1.0 2/17/2021
 */ 
package lab814;

import java.util.Scanner;

public class Lab814 {

    // The main program to get user inputs
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);
        int inputMethod = 0;
        
        // Generic introduction messages
        System.out.println("This program will take one date input and display " + 
                "the given date in different formats.");
        System.out.println("How would you like to enter your input?");
        System.out.println("Enter 1 for MM/DD/YYYY");
        System.out.println("Enter 2 for MONTH DD, YYYY");
        System.out.println("Enter 3 for DDD YYYY");
        inputMethod = console.nextInt();
        Date userDate = new Date();
        
        // Input method MM/DD/YYYY
        if (inputMethod == 1) {
            int mnth, dy, yr;
            
            System.out.print("Enter month number: ");
            mnth = console.nextInt();
            System.out.print("Enter day number: ");
            dy = console.nextInt();
            System.out.print("Enter year number: ");
            yr = console.nextInt();
            
            userDate.Date(dy, mnth, yr);
        }
        
        // Input method MONTH DD, YYYY
        if (inputMethod == 2) {
            String mnthS;
            int dy, yr;
            
            System.out.print("Please enter the month, spelled correctly: ");
            console.nextLine();
            mnthS = console.nextLine();
            System.out.print("Enter day number: ");
            dy = console.nextInt();
            System.out.print("Enter year number: ");
            yr = console.nextInt();
            
            userDate.Date(dy, mnthS, yr);
        }
        
        // Input method DDD YYYY
        if (inputMethod == 3) {
            int dynYr, yr;
            
            System.out.print("Enter the day number in the year (1-365): ");
            dynYr = console.nextInt();
            System.out.print("Enter the year number: ");
            yr = console.nextInt();
            
            userDate.Date(dynYr, yr);
        }
        
        // Displaying all the date formats
        userDate.displayDate();
    }
}