/*
 * CMPSCI 221 Exercise 8.14 Date Class
 * Date.java  
 * Purpose: To host the Date object that can take multiple forms of parameters
 *  
 * @author Mark Garas  
 * @version 1.0 2/17/2021
 */ 
package lab814;

// See below for an explanation of each variable
public class Date {
    private int day, month, year, dayInYear;
    private String monthString;
    private String[] monthsArray = {"January", "February", "March", "April", 
        "May", "June", "July", "August", "September", "October", "November", 
        "December"};
    private int[] daysAsYouGo = {0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 
        304, 334};
    private int[] daysInEachMonth = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30,
        31};
    
    // Initialization with 3 integers
    public void Date(int dy, int mnth, int yr) {
        day = dy;
        month = mnth;
        year = yr;
        monthString = monthsArray[mnth - 1];
        
        convertingToDDD(day, month);
    }
    
    // Initialization with month as a string input
    public void Date(int dy, String mnthS, int yr) {
        day = dy;
        
        // For every month name in the array of month names...
        for (int i = 0; i < 12; i++) {
            
            // If the given month name is the same as the current month in the 
            // array... Set the name and get the month number
            if (mnthS.equalsIgnoreCase(monthsArray[i])) {
                monthString = monthsArray[i];
                month = i + 1;
            }
        }
        year = yr;
        
        convertingToDDD(day, month);
    }
    
    // Initialization with only day in year and year given
    public void Date(int dynYr, int yr) {
        dayInYear = dynYr;
        year = yr;
        
        translatingFromDDD(dayInYear);
    }
    
    // Displays the date in the different forms
    public void displayDate() {
        String dayTensPlace = "";
        String monthTensPlace = "";
        
        // Just for clean printing purposes
        if (day < 10) {
            dayTensPlace = "0";
        }
        
        // See above
        if (month < 10) {
            monthTensPlace = "0";
        }
        
        System.out.println("------------------");
        System.out.println(monthTensPlace + month + "/" + dayTensPlace + day + 
                "/" + year);
        System.out.println(monthString + " " + day + ", " + year);
        System.out.println(dayInYear + " " + year);
        System.out.println("------------------");
    }
    
    // Converts the day in the month and month to day in the year
    public void convertingToDDD(int dy, int mnth) {
        dayInYear = daysAsYouGo[mnth - 1] + dy;
    }
    
    // Converts the "regular" day/month/year to the DDD YYYY format
    public void translatingFromDDD(int dy) {
        month = 0;
        
        // For every month in the year...
        for (int i = 0; i < 12; i++) {
            
            // Take off the amount of days in that month if you can and 
            // increment months
            if (dy > daysInEachMonth[i]) {
                dy -= daysInEachMonth[i];
                month++;
            }
        }
        
        day = dy;
        month++;
        monthString = monthsArray[month - 1];
    }
}

// day is the int for the day, same for month and year, and monthString holds 
// the String name for the month, monthsInYear is an array of all months for 
// conversion between int and string forms, dayInYear is the day of the year 
// (1-365), daysInMonths is an int array holding how many days in each month, 
// daysAsYouGo is an int[] that stores how many days have passed since every 
// month ignoring the day value, daysInEachMonth[] keeps track of days in each
// month