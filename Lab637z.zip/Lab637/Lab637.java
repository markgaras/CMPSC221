/**
 * CMPSCI 221 Exercise 6.37
 * Lab637.java  
 * Purpose: Teaching Simple Multiplication
 *  
 * @author Mark Garas  
 * @version 1.0 2/6/2021
 */ 
package lab637;

import java.util.Scanner;

public class Lab637 {

    public static void main(String[] args) {
        boolean keepRunning = true;
        int factor1, factor2, answer;
        Scanner console = new Scanner(System.in);
        RandomGenerator generator = new RandomGenerator();
        
        while (keepRunning) {
            System.out.println("Welcome to the virtual multiplication"
                    + " teacher!");
            System.out.println("After 10 answers, your multiplication aptitude "
                    + "will be displayed.");
            
            for (int i = 0; i < 10; i++) {
                
                if (generator.getResetQuestion()) {
                    generator.newQuestion();
                }
                factor1 = generator.getFirst();
                factor2 = generator.getSecond();
                System.out.print("How much is " + factor1 + " times " + factor2 
                        + "? ");
                answer = console.nextInt();
                generator.userAnswer(answer);
            }
        }
    }
}