/**
 * CMPSCI 221 Exercise 6.37
 * Lab637.java  
 * Purpose: Teaching Simple Multiplication Object
 *  
 * @author Mark Garas  
 * @version 1.0 2/6/2021
 */ 
package lab637;

import java.util.Random;
import java.util.Scanner;

public class RandomGenerator {
    // To see what each variable is for, please scroll to the bottom
    int first = 0, second = 0, correctAnswer = 0, answer, 
            questionsDone = 0, questionsRight = 0, messagePicker;
    double grade = 0;
    final int HIGHEST_FACTOR = 10, UPPERBOUND = 4, MAX_QUESTIONS = 10, 
            PERCENT_MULTIPLIER = 100;
    boolean resetQuestion = true;
    Random rand = new Random();
    Scanner console = new Scanner(System.in);
    
    public void newQuestion() {
        first = rand.nextInt(HIGHEST_FACTOR);
        second = rand.nextInt(HIGHEST_FACTOR);
        correctAnswer = first * second;
        resetQuestion = true;
    }
    
    // Returns the first factor to main
    public int getFirst() {
        return first;
    }
    
    // Returns the second factor to main
    public int getSecond() {
        return second;
    }
    
    // Returns whether or not the question sould be reset to main
    public boolean getResetQuestion() {
        return resetQuestion;
    }
    
    // Processing the user's inputted answer
    public void userAnswer(int answr) {
        answer = answr;
        questionsDone++;
        
        // If right answer given, award point, tell them they got it right, and
        // prepare to reset the question
        if (answer == correctAnswer) {
            questionsRight++;
            displayRight();
            resetQuestion = true;
        } else { // Otherwise, tell them they got it wrong and ask them again
            displayWrong();
            resetQuestion = false;
        }
        
        // If 10 answers have been given, move to the end of the program
        if (questionsDone == MAX_QUESTIONS) {
            displayFinal();
        }
    }
    
    // The end of the individual quizzes
    public void displayFinal() {
        // Calculate and displaying grade
        grade = ((double)questionsRight / (double)questionsDone) * 
                PERCENT_MULTIPLIER;
        System.out.println("Your grade is " + grade + "%.");
        
        // Tell the user whether or not they got a good grade
        if (grade >= 75) {
            System.out.println("Congratulations, you are ready to go to the "
                    + "next level!");
        } else {
            System.out.println("Please ask your teacher for extra help.");
        }
        
        // Moving to reset
        resetTeacher();
    }
    
    // Resetting the quiz for the next user, and displaying so
    public void resetTeacher() {
        questionsDone = 0;
        questionsRight = 0;
        System.out.println("Answer history cleared, press enter to start "
                + "another practice session.");
        console.nextLine();
        System.out.println("_______________________________________________\n");
    }
    
    // Displaying a randomized good blurb
    public void displayRight() {
        messagePicker = rand.nextInt(UPPERBOUND);
        switch (messagePicker) {
            case 0:
                System.out.println("Very good!");
                break;
            case 1:
                System.out.println("Excellent!");
                break;
            case 2:
                System.out.println("Nice work!");
                break;
            case 3:
                System.out.println("Keep up the good work!");
                break;
        }
    }
    
    // Displaying a randomized bad blurb
    public void displayWrong() {
        messagePicker = rand.nextInt(UPPERBOUND);
        switch (messagePicker) {
            case 0:
                System.out.println("No. Please try again.");
                break;
            case 1:
                System.out.println("Wrong. Try once more.");
                break;
            case 2:
                System.out.println("Don't give up!");
                break;
            case 3:
                System.out.println("No. Keep trying.");
                break;
        }
    }
}

/*
    first is the first random factor to be multiplied, second is the second 
    random factor to be multiplied, correctAnswer is the right answer to the 
    randomized question, answer is the user's answer, questionsDone is how many 
    questions the user has answered so far, questionsRight is how many 
    questions the user has answered correctly so far, message is the random 
    number used to pick a random message for both correct and incorrect 
    answers, grade is the total grade after 10 questions, HIGHEST_FACTOR is the 
    upperbound for the factor generator, UPPERBOUND is the upperbound for the 
    message generator, resetQuestion is a boolean value that checks for if the 
    program should reset the factors yet, rand is the Random object, console is
    user's text input, MAX_QUESTIONS is the top number of questions and can be 
    changed in code easily for longer tests, PERCENT_MULTIPLIERq is used to 
    muliply in order to get the percent of questions right
    */